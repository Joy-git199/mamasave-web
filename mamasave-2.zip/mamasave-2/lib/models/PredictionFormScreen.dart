import 'package:flutter/material.dart';
import 'package:mamasave/widgets/loading_overlay.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'api_service.dart';

class PredictionFormScreen extends StatefulWidget {
  @override
  _PredictionFormScreenState createState() => _PredictionFormScreenState();
}

class _PredictionFormScreenState extends State<PredictionFormScreen> {
  final _formKey = GlobalKey<FormState>();

  double? heartRate;
  double? bodyTemp;
  double? bloodOxygen;
  double? contractionFreq;
  double? contractionIntensity;

  String? predictionResult;
  bool isLoading = false;

  void submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      setState(() => isLoading = true);

      final api = ApiService();
      final result = await api.predictRisk(
        heartRate: heartRate!,
        bodyTemp: bodyTemp!,
        bloodOxygen: bloodOxygen!,
        contractionFreq: contractionFreq!,
        contractionIntensity: contractionIntensity!,
      );

      setState(() {
        predictionResult = result;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MamaSave Risk Prediction')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildNumberField('Heart Rate', (value) => heartRate = value),
              _buildNumberField('Body Temperature', (value) => bodyTemp = value),
              _buildNumberField('Blood Oxygen', (value) => bloodOxygen = value),
              _buildNumberField('Contraction Frequency', (value) => contractionFreq = value),
              _buildNumberField('Contraction Intensity', (value) => contractionIntensity = value),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: isLoading ? null : submitForm,
                child: isLoading ? CircularProgressIndicator() : Text('Predict'),
              ),
              if (predictionResult != null) ...[
                SizedBox(height: 20),
                Text('Predicted Risk Level: $predictionResult',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNumberField(String label, Function(double) onSaved) {
    return TextFormField(
      decoration: InputDecoration(labelText: label),
      keyboardType: TextInputType.number,
      validator: (value) => value == null || value.isEmpty ? 'Enter $label' : null,
      onSaved: (value) => onSaved(double.parse(value!)),
    );
  }
}
