// lib/models/vitals_entry.dart

import 'package:flutter/foundation.dart'; // For @required if not using null safety everywhere

// Represents a single entry of vital signs.
class VitalsEntry {
  final String id; // Unique identifier for the vitals entry
  final String motherId; // ID of the mother these vitals belong to
  final DateTime timestamp; // Date and time when the vitals were recorded
  final double? spo2; // Oxygen saturation (SpO2) percentage
  final double? temperature; // Body temperature in Celsius or Fahrenheit
  final int? heartRate; // Heart rate in beats per minute (BPM)
  final String? bloodPressure; // Blood pressure reading (e.g., "120/80 mmHg")
  // Removed weight and height as per user request
  // final double? weight;
  // final double? height;

  // Constructor for the VitalsEntry model.
  VitalsEntry({
    required this.id,
    required this.motherId,
    required this.timestamp,
    this.spo2,
    this.temperature,
    this.heartRate,
    this.bloodPressure,
    // Removed weight and height from constructor
    // this.weight,
    // this.height,
  });

  // Factory constructor to create a VitalsEntry object from a JSON map.
  factory VitalsEntry.fromJson(Map<String, dynamic> json) {
    return VitalsEntry(
      id: json['id'] as String,
      motherId: json['motherId'] as String,
      timestamp:
          DateTime.parse(json['timestamp'] as String), // Parse date string
      spo2: (json['spo2'] as num?)?.toDouble(), // Cast num to double
      temperature: (json['temperature'] as num?)?.toDouble(),
      heartRate: json['heartRate'] as int?,
      bloodPressure: json['bloodPressure'] as String?,
      // Removed weight and height from fromJson
      // weight: (json['weight'] as num?)?.toDouble(),
      // height: (json['height'] as num?)?.toDouble(),
    );
  }

  // Converts the VitalsEntry object to a JSON map.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'motherId': motherId,
      'timestamp':
          timestamp.toIso8601String(), // Convert DateTime to ISO 8601 string
      'spo2': spo2,
      'temperature': temperature,
      'heartRate': heartRate,
      'bloodPressure': bloodPressure,
      // Removed weight and height from toJson
      // 'weight': weight,
      // 'height': height,
    };
  }

  // Provides a string representation of the VitalsEntry object for debugging.
  @override
  String toString() {
    return 'VitalsEntry(id: $id, motherId: $motherId, timestamp: $timestamp, SpO2: $spo2, Temp: $temperature, HR: $heartRate)';
  }
}
