// lib/models/health_visit.dart

import 'package:flutter/foundation.dart'; // For @required if not using null safety everywhere
import '../models/vitals_entry.dart'; // Import VitalsEntry model

// Represents a single health visit record for a mother.
class HealthVisit {
  final String id; // Unique identifier for the visit
  final String motherId; // ID of the mother associated with this visit
  final DateTime visitDate; // Date and time of the visit
  final String
      visitorRole; // Role of the person conducting the visit (e.g., "CHW", "Midwife")
  final String?
      visitorId; // Optional: ID of the CHW or Midwife who conducted the visit
  final String? notes; // General notes about the visit
  final VitalsEntry? vitals; // Vitals recorded during this visit
  final List<String>
      dangerSigns; // List of danger signs observed (e.g., "Fever", "Swelling")
  final String? recommendations; // Recommendations given during the visit

  // Constructor for the HealthVisit model.
  HealthVisit({
    required this.id,
    required this.motherId,
    required this.visitDate,
    required this.visitorRole,
    this.visitorId,
    this.notes,
    this.vitals,
    this.dangerSigns = const [], // Default to an empty list
    this.recommendations,
  });

  // Factory constructor to create a HealthVisit object from a JSON map.
  factory HealthVisit.fromJson(Map<String, dynamic> json) {
    return HealthVisit(
      id: json['id'] as String,
      motherId: json['motherId'] as String,
      visitDate:
          DateTime.parse(json['visitDate'] as String), // Parse date string
      visitorRole: json['visitorRole'] as String,
      visitorId: json['visitorId'] as String?,
      notes: json['notes'] as String?,
      // Convert vitals JSON to VitalsEntry object if present
      vitals: json['vitals'] != null
          ? VitalsEntry.fromJson(json['vitals'] as Map<String, dynamic>)
          : null,
      dangerSigns: List<String>.from(
          json['dangerSigns'] as List), // Cast to List<String>
      recommendations: json['recommendations'] as String?,
    );
  }

  // Converts the HealthVisit object to a JSON map.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'motherId': motherId,
      'visitDate':
          visitDate.toIso8601String(), // Convert DateTime to ISO 8601 string
      'visitorRole': visitorRole,
      'visitorId': visitorId,
      'notes': notes,
      'vitals': vitals?.toJson(), // Convert VitalsEntry to JSON if not null
      'dangerSigns': dangerSigns,
      'recommendations': recommendations,
    };
  }

  // Provides a string representation of the HealthVisit object for debugging.
  @override
  String toString() {
    return 'HealthVisit(id: $id, motherId: $motherId, visitDate: $visitDate, visitorRole: $visitorRole)';
  }
}
