import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _baseUrl = 'http://127.0.0.1:8000'; // Change to your IP on real device

  static Future<String> predictRisk({
    required double heartRate,
    required double bodyTemp,
    required double bloodOxygen,
    required double contractionFreq,
    required double contractionIntensity,
  }) async {
    final url = Uri.parse('$_baseUrl/predict');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'HeartRate': heartRate,
        'BodyTemp': bodyTemp,
        'BloodOxygen': bloodOxygen,
        'ContractionFreq': contractionFreq,
        'ContractionIntensity': contractionIntensity,
      }),
    );

    if (response.statusCode == 200) {
      // Response is just a plain string like "Low", "Mid", or "High"
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to predict risk: ${response.body}');
    }
  }
}
// This class provides a method to send a POST request to the prediction API
// with the necessary parameters and returns the risk prediction as a string.