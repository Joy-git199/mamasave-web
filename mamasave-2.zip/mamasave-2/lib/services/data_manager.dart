// lib/services/data_manager.dart

import 'package:flutter/material.dart';
import 'package:mamasave/models/contact.dart';
import 'package:mamasave/models/health_visit.dart';
import 'package:mamasave/models/personal_note.dart';
import 'package:mamasave/models/vitals_entry.dart';
import 'package:uuid/uuid.dart';

// DataManager class handles all mock data operations for the application.
// It simulates fetching, adding, and managing data for mothers, CHWs, and midwives.
class DataManager with ChangeNotifier {
  // --- Mock Data Storage ---
  // Using Maps and Lists to simulate a database.
  final Map<String, Map<String, dynamic>> _users = {
    'mother_001': {
      'id': 'mother_001',
      'name': 'Aisha Nakato',
      'email': 'aisha.nakato@example.com',
      'phone': '+256771234567',
      'age': 28,
      'location': 'Kampala',
      'pregnancyStatus': 'Week 25',
      'assignedCHW': 'Alice CHW',
      'assignedMidwife': 'Dr. Sarah',
      'role': 'mother',
    },
    'chw_mock': {
      'id': 'chw_mock',
      'name': 'Alice CHW',
      'email': 'alice.chw@example.com',
      'role': 'chw',
    },
    'midwife_mock': {
      'id': 'midwife_mock',
      'name': 'Dr. Sarah',
      'email': 'dr.sarah@example.com',
      'role': 'midwife',
    },
  };

  final List<VitalsEntry> _vitalsEntries = [
    VitalsEntry(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      timestamp: DateTime.now().subtract(const Duration(days: 30)),
      spo2: 98.0,
      temperature: 36.8,
      heartRate: 75,
      bloodPressure: '110/70',
      // Removed weight and height
    ),
    VitalsEntry(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      timestamp: DateTime.now().subtract(const Duration(days: 15)),
      spo2: 97.5,
      temperature: 37.1,
      heartRate: 80,
      bloodPressure: '115/75',
      // Removed weight and height
    ),
    VitalsEntry(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      timestamp: DateTime.now().subtract(const Duration(days: 5)),
      spo2: 99.0,
      temperature: 36.9,
      heartRate: 78,
      bloodPressure: '120/80',
      // Removed weight and height
    ),
  ];

  final List<HealthVisit> _healthVisits = [
    HealthVisit(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      visitDate: DateTime.now().subtract(const Duration(days: 40)),
      visitorRole: 'CHW',
      visitorId: 'chw_mock',
      notes: 'Initial assessment, mother is doing well.',
      vitals: VitalsEntry(
        id: const Uuid().v4(),
        motherId: 'mother_001',
        timestamp: DateTime.now().subtract(const Duration(days: 40)),
        spo2: 98.0,
        temperature: 36.8,
        heartRate: 75,
        bloodPressure: '110/70',
      ),
      dangerSigns: [],
    ),
    HealthVisit(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      visitDate: DateTime.now().subtract(const Duration(days: 20)),
      visitorRole: 'Midwife',
      visitorId: 'midwife_mock',
      notes: 'Routine check-up, advised on nutrition.',
      vitals: VitalsEntry(
        id: const Uuid().v4(),
        motherId: 'mother_001',
        timestamp: DateTime.now().subtract(const Duration(days: 20)),
        spo2: 97.5,
        temperature: 37.1,
        heartRate: 80,
        bloodPressure: '115/75',
      ),
      dangerSigns: [],
    ),
    HealthVisit(
      id: const Uuid().v4(),
      motherId: 'mother_001',
      visitDate: DateTime.now().subtract(const Duration(days: 1)),
      visitorRole: 'Self-Reported',
      visitorId: 'mother_001',
      notes: 'Felt dizzy after standing up quickly.',
      vitals: null, // No vitals recorded for this self-report
      dangerSigns: ['Dizziness'],
      recommendations: 'Emergency services alerted.',
    ),
  ];

  final List<Contact> _emergencyContacts = [
    Contact(
      id: const Uuid().v4(),
      name: 'John Doe',
      phoneNumber: '+256781234567',
      relationship: 'Husband',
      isEmergencyContact: true,
    ),
    Contact(
      id: const Uuid().v4(),
      name: 'Jane Smith',
      phoneNumber: '+256755112233',
      relationship: 'Sister',
      isEmergencyContact: true,
    ),
  ];

  final List<PersonalNote> _personalNotes = [
    PersonalNote(
      id: const Uuid().v4(),
      userId: 'mother_001',
      title: 'Grocery List',
      content: 'Milk, eggs, bread, fruits, vegetables.',
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
    ),
    PersonalNote(
      id: const Uuid().v4(),
      userId: 'mother_001',
      title: 'Questions for Midwife',
      content:
          'Ask about exercise during third trimester. Discuss birth plan options.',
      createdAt: DateTime.now().subtract(const Duration(days: 2)),
    ),
  ];

  // --- User Management ---
  Map<String, dynamic>? getUserById(String userId) {
    return _users[userId];
  }

  // New method to update user data
  void updateUser(String userId, Map<String, dynamic> newData) {
    if (_users.containsKey(userId)) {
      _users[userId]!.addAll(newData);
      notifyListeners(); // Notify listeners that user data has changed
    }
  }

  List<Map<String, dynamic>> getAllMothers() {
    return _users.values.where((user) => user['role'] == 'mother').toList();
  }

  String getMotherNameById(String motherId) {
    return _users[motherId]?['name'] ?? 'Unknown Mother';
  }

  String getMotherPregnancyStatus(String motherId) {
    return _users[motherId]?['pregnancyStatus'] ?? 'Status not set';
  }

  List<String> getAllMotherIds() {
    return _users.keys.where((id) => _users[id]?['role'] == 'mother').toList();
  }

  // --- Vitals Management ---
  List<VitalsEntry> getVitalsEntriesForMother(String motherId) {
    return _vitalsEntries.where((v) => v.motherId == motherId).toList();
  }

  Future<void> addVitalsEntry(VitalsEntry entry) async {
    _vitalsEntries.add(entry);
    notifyListeners();
  }

  // --- Health Visit Management ---
  List<HealthVisit> getAllHealthVisits() {
    return _healthVisits;
  }

  List<HealthVisit> getHealthVisitsForMother(String motherId) {
    return _healthVisits.where((visit) => visit.motherId == motherId).toList();
  }

  Future<void> addHealthVisit(HealthVisit visit) async {
    _healthVisits.add(visit);
    notifyListeners();
  }

  List<HealthVisit> getRecentEmergencyReports() {
    // Filter visits that have danger signs and sort by most recent
    return _healthVisits.where((visit) => visit.dangerSigns.isNotEmpty).toList()
      ..sort((a, b) => b.visitDate.compareTo(a.visitDate));
  }

  List<HealthVisit> getUpcomingVisits() {
    // Mock upcoming visits (e.g., next 7 days)
    final now = DateTime.now();
    return _healthVisits
        .where((visit) =>
            visit.visitDate.isAfter(now) &&
            visit.visitDate.isBefore(now.add(const Duration(days: 7))))
        .toList()
      ..sort((a, b) => a.visitDate.compareTo(b.visitDate));
  }

  // --- Emergency Contact Management ---
  List<Contact> getEmergencyContactsForMother(String motherId) {
    return _emergencyContacts.where((c) => c.isEmergencyContact).toList();
  }

  Future<void> addEmergencyContact(String motherId, Contact contact) async {
    if (contact.isEmergencyContact) {
      _emergencyContacts.add(contact);
      notifyListeners();
    }
  }

  Future<void> removeEmergencyContact(String motherId, String contactId) async {
    _emergencyContacts.removeWhere((contact) => contact.id == contactId);
    notifyListeners();
  }

  // --- Personal Notes Management ---
  List<PersonalNote> getPersonalNotesForMother(String motherId) {
    return _personalNotes.where((note) => note.userId == motherId).toList();
  }

  Future<void> addPersonalNote(String motherId, PersonalNote note) async {
    _personalNotes.add(note);
    notifyListeners();
  }

  Future<void> removePersonalNote(String motherId, String noteId) async {
    _personalNotes.removeWhere((note) => note.id == noteId);
    notifyListeners();
  }

  // --- Midwife Specific Stats ---
  Map<String, int> getMidwifeSummaryStats() {
    final totalMothers =
        _users.values.where((user) => user['role'] == 'mother').length;
    final pregnantMothers = _users.values
        .where((user) =>
            user['role'] == 'mother' &&
            user['pregnancyStatus'] != null &&
            user['pregnancyStatus'].startsWith('Week'))
        .length;
    final postnatalMothers = totalMothers - pregnantMothers;
    final emergencies =
        _healthVisits.where((visit) => visit.dangerSigns.isNotEmpty).length;

    return {
      'totalMothers': totalMothers,
      'pregnantMothers': pregnantMothers,
      'postnatalMothers': postnatalMothers,
      'emergencies': emergencies,
    };
  }
}
