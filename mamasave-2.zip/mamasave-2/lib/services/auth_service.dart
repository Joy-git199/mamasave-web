// lib/services/auth_service.dart

import 'package:flutter/material.dart';
import 'dart:async'; // Import for StreamController

// AuthService handles user authentication (login, signup, logout)
// and manages the current user's state.
class AuthService with ChangeNotifier {
  // Mock user data storage
  final Map<String, Map<String, dynamic>> _users = {
    'mother@example.com': {
      'password': 'password123',
      'role': 'mother',
      'name': 'Jane Doe'
    },
    'chw@example.com': {
      'password': 'password123',
      'role': 'chw',
      'name': 'Alice CHW'
    },
    'midwife@example.com': {
      'password': 'password123',
      'role': 'midwife',
      'name': 'Dr. Sarah'
    },
  };

  String? _currentUserId;
  String? _currentUserEmail;
  String? _currentUserRole;

  // StreamController to notify listeners about authentication state changes.
  // It emits the current user's UID (or null if logged out).
  final StreamController<String?> _authStateController =
      StreamController<String?>.broadcast();

  // Public getter for the authentication state stream.
  Stream<String?> get onAuthStateChanged => _authStateController.stream;

  String? get currentUserUid =>
      _currentUserId; // Corrected getter name to match usage
  String? get currentUserEmail => _currentUserEmail;
  String? get currentUserRole => _currentUserRole;

  // Simulates user login.
  // Takes only email and password as arguments.
  Future<bool> login(String email, String password) async {
    await Future.delayed(const Duration(seconds: 1)); // Simulate network delay

    if (_users.containsKey(email) && _users[email]!['password'] == password) {
      _currentUserEmail = email;
      _currentUserRole = _users[email]!['role'];
      // For mock purposes, assign a simple ID based on email
      _currentUserId =
          email.split('@')[0]; // e.g., 'mother' from 'mother@example.com'
      _authStateController.add(_currentUserId); // Emit the new user ID
      notifyListeners();
      return true;
    }
    _authStateController.add(null); // Emit null if login fails
    return false;
  }

  // Simulates user signup.
  // Takes name, email, password, and role as arguments.
  Future<bool> signup(
      String name, String email, String password, String role) async {
    await Future.delayed(const Duration(seconds: 1)); // Simulate network delay

    if (_users.containsKey(email)) {
      return false; // User already exists
    }

    _users[email] = {'password': password, 'role': role, 'name': name};
    // Automatically log in after signup for convenience
    final success = await login(email, password);
    return success;
  }

  // Simulates user logout.
  Future<void> logout() async {
    await Future.delayed(
        const Duration(milliseconds: 500)); // Simulate network delay
    _currentUserId = null;
    _currentUserEmail = null;
    _currentUserRole = null;
    _authStateController.add(null); // Emit null to indicate logout
    notifyListeners();
  }

  // Checks if a user is currently logged in.
  bool isLoggedIn() {
    return _currentUserEmail != null;
  }

  // Dispose method to close the StreamController when AuthService is no longer needed.
  @override
  void dispose() {
    _authStateController.close();
    super.dispose();
  }
}
