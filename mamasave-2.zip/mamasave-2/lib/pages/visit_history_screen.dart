// lib/pages/visit_history_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/data_manager.dart';
import 'package:mamasave/models/health_visit.dart';

// The VisitHistoryScreen displays a comprehensive list of health visits.
// This screen can be adapted to show visits for a specific mother (if navigated from MotherDashboard)
// or visits conducted by a specific CHW/Midwife (if navigated from their dashboards).
class VisitHistoryScreen extends StatelessWidget {
  final String? userId; // Optional: ID of the user (mother, CHW, or midwife)
  final String? role; // Optional: Role of the user for filtering purposes

  const VisitHistoryScreen({super.key, this.userId, this.role});

  @override
  Widget build(BuildContext context) {
    final dataManager = Provider.of<DataManager>(context);
    List<HealthVisit> visits = [];
    String screenTitle = 'Visit History';

    if (role == 'Mother' && userId != null) {
      visits = dataManager.getHealthVisitsForMother(userId!);
      screenTitle =
          '${dataManager.getMotherNameById(userId!)}\'s Visit History';
    } else if (role == 'CHW' && userId != null) {
      visits = dataManager
          .getAllHealthVisits()
          .where((visit) =>
              visit.visitorId == userId && visit.visitorRole == 'CHW')
          .toList();
      screenTitle =
          '${dataManager.getUserById(userId!)?['name'] ?? 'CHW'}\'s Visit History';
    } else if (role == 'Midwife' && userId != null) {
      visits = dataManager
          .getAllHealthVisits()
          .where((visit) =>
              visit.visitorId == userId && visit.visitorRole == 'Midwife')
          .toList();
      screenTitle =
          '${dataManager.getUserById(userId!)?['name'] ?? 'Midwife'}\'s Visit History';
    } else {
      // Default: Show all visits (e.g., for an admin view or if no specific user context)
      visits = dataManager.getAllHealthVisits();
      screenTitle = 'All Health Visits';
    }

    // Sort visits by date, most recent first.
    visits.sort((a, b) => b.visitDate.compareTo(a.visitDate));

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(screenTitle),
      ),
      body: visits.isEmpty
          ? Center(
              child: Text(
                'No visit history available.',
                style:
                    AppStyles.bodyText1.copyWith(fontStyle: FontStyle.italic),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: visits.length,
              itemBuilder: (context, index) {
                final visit = visits[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8.0),
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Visit Date: ${visit.visitDate.toLocal().toString().split(' ')[0]}',
                          style: AppStyles.subTitle
                              .copyWith(color: AppColors.primaryColor),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Mother: ${dataManager.getMotherNameById(visit.motherId)}',
                          style: AppStyles.bodyText1,
                        ),
                        Text(
                          'Conducted by: ${visit.visitorRole} (${dataManager.getUserById(visit.visitorId ?? '')?['name'] ?? 'N/A'})',
                          style: AppStyles.bodyText2,
                        ),
                        if (visit.vitals != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Vitals: SpO2 ${visit.vitals!.spo2?.toStringAsFixed(1) ?? 'N/A'}%, Temp ${visit.vitals!.temperature?.toStringAsFixed(1) ?? 'N/A'}°C, HR ${visit.vitals!.heartRate ?? 'N/A'} bpm, BP ${visit.vitals!.bloodPressure ?? 'N/A'}',
                            style: AppStyles.bodyText2,
                          ),
                        ],
                        if (visit.dangerSigns.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Danger Signs: ${visit.dangerSigns.join(', ')}',
                            style: AppStyles.bodyText2.copyWith(
                                color: AppColors.dangerColor,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                        if (visit.notes != null && visit.notes!.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Notes: ${visit.notes}',
                            style: AppStyles.bodyText2,
                          ),
                        ],
                        if (visit.recommendations != null &&
                            visit.recommendations!.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Recommendations: ${visit.recommendations}',
                            style: AppStyles.bodyText2
                                .copyWith(fontStyle: FontStyle.italic),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
