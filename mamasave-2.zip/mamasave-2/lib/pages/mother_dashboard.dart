// lib/pages/mother_dashboard.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/auth_service.dart';
import 'package:mamasave/services/data_manager.dart';
import 'package:mamasave/models/vitals_entry.dart';
import 'package:mamasave/models/health_visit.dart';
import 'package:mamasave/widgets/custom_snackbar.dart';
import 'package:uuid/uuid.dart';

// The MotherDashboard provides a personalized view for mothers.
// It displays real-time vitals, emergency status, visit history, and health tips.
class MotherDashboard extends StatefulWidget {
  const MotherDashboard({super.key});

  @override
  State<MotherDashboard> createState() => _MotherDashboardState();
}

class _MotherDashboardState extends State<MotherDashboard> {
  // Mock user ID for the mother. In a real app, this would come from AuthService.
  // We'll use a fixed mock ID for demonstration purposes.
  final String _currentMotherId = 'mother_001'; // Example mock ID

  @override
  Widget build(BuildContext context) {
    // Listen to DataManager for updates to vitals and health visits.
    final dataManager = Provider.of<DataManager>(context);
    final authService = Provider.of<AuthService>(context);

    // Get mock data for the current mother.
    final Map<String, dynamic>? currentUser =
        dataManager.getUserById(_currentMotherId);
    final List<VitalsEntry> vitals =
        dataManager.getVitalsEntriesForMother(_currentMotherId);
    final List<HealthVisit> visits =
        dataManager.getHealthVisitsForMother(_currentMotherId);

    // Get the most recent vitals entry, if available.
    final VitalsEntry? latestVitals = vitals.isNotEmpty
        ? vitals.reduce((a, b) => a.timestamp.isAfter(b.timestamp) ? a : b)
        : null;

    final String motherName = currentUser?['name'] ?? 'MamaSave User';
    final String pregnancyStatus =
        dataManager.getMotherPregnancyStatus(_currentMotherId);

    return Scaffold(
      backgroundColor:
          Theme.of(context).scaffoldBackgroundColor, // Use theme color
      appBar: AppBar(
        title: const Text('Mother Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              Navigator.of(context)
                  .pushNamed('/mother_profile'); // Navigate to profile
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authService.logout();
              Navigator.of(context)
                  .pushReplacementNamed('/'); // Go back to splash/onboarding
              CustomSnackBar.showInfo(context, 'You have been logged out.');
            },
          ),
        ],
      ),
      drawer:
          _buildDrawer(context, authService, motherName), // Navigation drawer
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome message and current status
            Text(
              'Hello, $motherName!',
              style: AppStyles.headline2.copyWith(
                  color: Theme.of(context).textTheme.displayMedium?.color),
            ),
            const SizedBox(height: 8),
            Text(
              pregnancyStatus, // Dynamic pregnancy status
              style: AppStyles.subTitle.copyWith(
                  color: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.color), // Use theme text color
            ),
            const SizedBox(height: 24),

            // Real-time Vitals Section
            _buildSectionTitle('Your Vitals', Icons.monitor_heart, context),
            const SizedBox(height: 16),
            _buildVitalsCard(latestVitals, context),
            const SizedBox(height: 24),

            // Emergency Button
            _buildEmergencyButton(context),
            const SizedBox(height: 24),

            // Health Tips Section
            _buildSectionTitle('Health Tips', Icons.lightbulb_outline, context),
            const SizedBox(height: 16),
            _buildHealthTips(context),
            const SizedBox(height: 24),

            // Visit History Section
            _buildSectionTitle('Visit History', Icons.history, context),
            const SizedBox(height: 16),
            _buildVisitHistory(visits, context),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // Builds a section title with an icon.
  Widget _buildSectionTitle(String title, IconData icon, BuildContext context) {
    return Row(
      children: [
        Icon(icon,
            color: Theme.of(context).primaryColor,
            size: 28), // Use theme primary color
        const SizedBox(width: 10),
        Text(
          title,
          style: AppStyles.headline3
              .copyWith(color: Theme.of(context).textTheme.displaySmall?.color),
        ),
      ],
    );
  }

  // Builds the vitals display card.
  Widget _buildVitalsCard(VitalsEntry? vitals, BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Pass the motherId to the VitalsGraphScreen
        Navigator.of(context).pushNamed(
          '/vitals_graph',
          arguments: {'motherId': _currentMotherId},
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: AppStyles.cardDecoration(context),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Last Updated: ${vitals?.timestamp.toLocal().toString().split(' ')[0] ?? 'N/A'}',
              style: AppStyles.bodyText2.copyWith(
                  color: Theme.of(context).textTheme.bodyMedium?.color),
            ),
            const SizedBox(height: 15),
            LayoutBuilder(
              builder: (context, constraints) {
                // Adjust layout based on screen width
                return Row(
                  // Simplified layout as weight/height are removed
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildVitalsItem(
                        'SpO2',
                        '${vitals?.spo2?.toStringAsFixed(1) ?? 'N/A'}%',
                        Icons.monitor,
                        context),
                    _buildVitalsItem(
                        'Temp',
                        '${vitals?.temperature?.toStringAsFixed(1) ?? 'N/A'}°C',
                        Icons.thermostat,
                        context),
                    _buildVitalsItem('HR', '${vitals?.heartRate ?? 'N/A'} bpm',
                        Icons.favorite_border, context),
                  ],
                );
              },
            ),
            const SizedBox(height: 15),
            Text(
              'Blood Pressure: ${vitals?.bloodPressure ?? 'N/A'}',
              style: AppStyles.bodyText1.copyWith(
                  color: Theme.of(context).textTheme.bodyLarge?.color),
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                'Tap to view trends',
                style: AppStyles.bodyText2.copyWith(
                    color: Theme.of(context).textTheme.bodyMedium?.color),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper for individual vital sign display.
  Widget _buildVitalsItem(
      String label, String value, IconData icon, BuildContext context) {
    return Column(
      children: [
        Icon(icon,
            size: 30,
            color:
                Theme.of(context).hintColor), // Use theme hint color for accent
        const SizedBox(height: 5),
        Text(label,
            style: AppStyles.bodyText2.copyWith(
                color: Theme.of(context).textTheme.bodyMedium?.color)),
        Text(value,
            style: AppStyles.headline3.copyWith(
                color: Theme.of(context).textTheme.displaySmall?.color)),
      ],
    );
  }

  // Builds the panic button.
  Widget _buildEmergencyButton(BuildContext context) {
    return Center(
      child: ElevatedButton.icon(
        onPressed: () {
          // TODO: Implement actual emergency contact logic (e.g., call, send alert)
          CustomSnackBar.showWarning(context,
              'Emergency button pressed! Sending alert to emergency contacts...');
          // Add a mock panic event to history
          final dataManager = Provider.of<DataManager>(context, listen: false);
          dataManager.addHealthVisit(HealthVisit(
            id: const Uuid().v4(),
            motherId: _currentMotherId,
            visitDate: DateTime.now(),
            visitorRole: 'Self-Reported',
            notes: 'Panic button activated.',
            dangerSigns: ['Panic Button Activated'],
            recommendations: 'Emergency services alerted.',
          ));
        },
        icon: const Icon(Icons.warning_amber_rounded, size: 30),
        label: Text('Panic Button',
            style: AppStyles.buttonTextStyle.copyWith(fontSize: 18)),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.dangerColor, // Red for emergency
          foregroundColor: AppColors.whiteTextColor, // Correct: direct access
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          elevation: 8,
        ),
      ),
    );
  }

  // Builds the health tips section.
  Widget _buildHealthTips(BuildContext context) {
    // Pass context
    final List<String> tips = [
      'Stay hydrated, drink at least 8 glasses of water daily.',
      'Eat a balanced diet rich in fruits, vegetables, and lean protein.',
      'Get regular, moderate exercise as advised by your doctor.',
      'Ensure you get adequate rest, aim for 7-9 hours of sleep.',
      'Attend all your scheduled prenatal appointments.',
      'Practice deep breathing exercises to manage stress.',
      'Avoid smoking and alcohol during pregnancy.',
      'Report any unusual symptoms to your CHW or midwife immediately.',
    ];

    return Container(
      decoration: AppStyles.cardDecoration(context),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: tips
            .map((tip) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.check_circle_outline,
                          size: 20, color: AppColors.successColor),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(tip,
                            style: AppStyles.bodyText2.copyWith(
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.color)),
                      ),
                    ],
                  ),
                ))
            .toList(),
      ),
    );
  }

  // Builds the visit history section.
  Widget _buildVisitHistory(List<HealthVisit> visits, BuildContext context) {
    // Pass context
    if (visits.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16.0),
        decoration: AppStyles.cardDecoration(context),
        child: Center(
          child: Text(
            'No visit history available yet.',
            style: AppStyles.bodyText2.copyWith(
                fontStyle: FontStyle.italic,
                color: Theme.of(context).textTheme.bodyMedium?.color),
          ),
        ),
      );
    }

    // Sort visits by date, most recent first.
    visits.sort((a, b) => b.visitDate.compareTo(a.visitDate));

    return Container(
      decoration: AppStyles.cardDecoration(context),
      child: ListView.builder(
        shrinkWrap: true, // Important for nested list views
        physics:
            const NeverScrollableScrollPhysics(), // Disable scrolling for this list
        itemCount:
            visits.length > 3 ? 3 : visits.length, // Show only top 3 or fewer
        itemBuilder: (context, index) {
          final visit = visits[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            elevation: 0, // Cards within a card, so no extra elevation
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0)),
            color: Theme.of(context)
                .scaffoldBackgroundColor, // Use scaffold background for nested cards
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Visit on: ${visit.visitDate.toLocal().toString().split(' ')[0]}',
                    style: AppStyles.subTitle
                        .copyWith(color: Theme.of(context).primaryColor),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Conducted by: ${visit.visitorRole}',
                    style: AppStyles.bodyText2.copyWith(
                        color: Theme.of(context).textTheme.bodyMedium?.color),
                  ),
                  if (visit.notes != null && visit.notes!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Notes: ${visit.notes}',
                        style: AppStyles.bodyText2.copyWith(
                            color:
                                Theme.of(context).textTheme.bodyMedium?.color),
                      ),
                    ),
                  if (visit.dangerSigns.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Danger Signs: ${visit.dangerSigns.join(', ')}',
                        style: AppStyles.bodyText2.copyWith(
                            color: AppColors.dangerColor,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  if (visit.vitals != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Vitals: SpO2 ${visit.vitals!.spo2?.toStringAsFixed(1) ?? 'N/A'}%, Temp ${visit.vitals!.temperature?.toStringAsFixed(1) ?? 'N/A'}°C, HR ${visit.vitals!.heartRate ?? 'N/A'} bpm, BP ${visit.vitals!.bloodPressure ?? 'N/A'}',
                        style: AppStyles.bodyText2.copyWith(
                            color:
                                Theme.of(context).textTheme.bodyMedium?.color),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // Builds the navigation drawer for the Mother's dashboard.
  Widget _buildDrawer(
      BuildContext context, AuthService authService, String userName) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppColors.whiteTextColor.withOpacity(0.8),
                  child: Icon(
                    Icons.person,
                    size: 40,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  userName,
                  style: AppStyles.headline3
                      .copyWith(color: AppColors.whiteTextColor),
                ),
                Text(
                  'Mother Role',
                  style: AppStyles.bodyText2.copyWith(
                      color: AppColors.whiteTextColor.withOpacity(0.8)),
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.home,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Home (Dashboard)',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              // Assuming HomePage manages bottom nav, this will go to index 0
              Navigator.of(context).pushReplacementNamed('/home');
            },
          ),
          ListTile(
            leading: Icon(Icons.history,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Visit History',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed(
                '/visit_history',
                arguments: {'userId': _currentMotherId, 'role': 'Mother'},
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.monitor_heart,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Vitals Trends',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed(
                '/vitals_graph',
                arguments: {'motherId': _currentMotherId},
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.warning_amber_rounded,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Panic History',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/panic_history');
            },
          ),
          ListTile(
            leading: Icon(Icons.lightbulb_outline,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Health Tips',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/health_tips');
            },
          ),
          ListTile(
            leading: Icon(Icons.person_outline,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('My Profile (Contacts & Notes)',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/mother_profile');
            },
          ),
          ListTile(
            leading: Icon(Icons.upload_file,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Documents & Records',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/documents_upload');
            },
          ),
          ListTile(
            leading: Icon(Icons.pregnant_woman,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Pregnancy Progress',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context)
                  .pushNamed('/pregnancy_progress'); // Direct navigation
            },
          ),
          const Divider(),
          ListTile(
            leading: Icon(Icons.settings,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Settings',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/settings');
            },
          ),
          ListTile(
            leading: Icon(Icons.help_outline,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Help & Support',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/help_support');
            },
          ),
          ListTile(
            leading: Icon(Icons.logout, color: AppColors.dangerColor),
            title: Text('Logout',
                style:
                    AppStyles.bodyText1.copyWith(color: AppColors.dangerColor)),
            onTap: () async {
              Navigator.pop(context);
              await authService.logout();
              Navigator.of(context).pushReplacementNamed('/');
              CustomSnackBar.showInfo(context, 'You have been logged out.');
            },
          ),
        ],
      ),
    );
  }
}
