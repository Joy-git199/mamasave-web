// lib/pages/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/widgets/custom_snackbar.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/services/auth_service.dart';
import 'package:mamasave/services/theme_notifier.dart';
import 'package:mamasave/services/data_manager.dart'; // Import DataManager
import 'dart:async'; // Import for StreamSubscription

// The SettingsScreen provides various application settings, including theme selection.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Mock settings toggles (these would typically be stored persistently)
  bool _inAppMessagingEnabled = true;
  bool _receiveVisitReminders = true;
  bool _getWeeklyTips = true;
  bool _panicAlertConfirmations = true;
  bool _offlineModeEnabled =
      false; // This is a placeholder for a complex feature

  String _selectedLanguage = 'English'; // Default selected language

  // Controllers for Change Password Dialog
  final TextEditingController _currentPasswordController =
      TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmNewPasswordController =
      TextEditingController();

  // Controllers for Edit Profile Dialog
  final TextEditingController _editNameController = TextEditingController();
  final TextEditingController _editEmailController = TextEditingController();
  final TextEditingController _editPhoneController = TextEditingController();
  final TextEditingController _editAgeController = TextEditingController();
  final TextEditingController _editLocationController = TextEditingController();

  // Current user ID will be fetched from AuthService
  String? _currentUserUid;
  // A flag to indicate if the auth state has been initially checked
  bool _isAuthChecked = false;

  // StreamSubscription to manage the auth state listener
  StreamSubscription? _authSubscription;

  // Declare authService as late final to ensure it's initialized once in didChangeDependencies
  late final AuthService _authServiceInstance;

  @override
  void initState() {
    super.initState();
    // No direct Provider.of calls here. Defer to didChangeDependencies.
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // This method is called immediately after initState and whenever the dependencies of this
    // State object change. It's a safe place to call Provider.of.
    if (!_isAuthChecked) {
      // Ensure this logic runs only once
      // Initialize _authServiceInstance here. Provider.of will throw if not found.
      _authServiceInstance = Provider.of<AuthService>(context, listen: false);

      // Immediately check if a user is already logged in (e.g., if app was resumed)
      _currentUserUid = _authServiceInstance
          .currentUserUid; // Access via the non-nullable instance
      _isAuthChecked = true; // Mark as checked

      // Set up the listener for authentication state changes.
      // This will update _currentUserUid if the user logs in/out while on this screen.
      _authSubscription = _authServiceInstance.onAuthStateChanged.listen((uid) {
        // Access via the non-nullable instance
        if (mounted) {
          // Ensure the widget is still in the tree before calling setState
          setState(() {
            _currentUserUid = uid;
            // No need to set _isAuthChecked to true again here, it's already true.
          });
        }
      });
    }
  }

  @override
  void dispose() {
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmNewPasswordController.dispose();
    _editNameController.dispose();
    _editEmailController.dispose();
    _editPhoneController.dispose();
    _editAgeController.dispose();
    _editLocationController.dispose();
    _authSubscription
        ?.cancel(); // Safely cancel the subscription if it's not null
    super.dispose();
  }

  // Function to show Change Password Dialog
  void _showChangePasswordDialog(
      BuildContext context, AuthService authService) {
    if (_currentUserUid == null) {
      CustomSnackBar.showError(
          context, 'You must be logged in to change your password.');
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Change Password'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _currentPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Current Password',
                    prefixIcon: Icon(Icons.lock_outline,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _newPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'New Password',
                    prefixIcon: Icon(Icons.lock_reset_outlined,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _confirmNewPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Confirm New Password',
                    prefixIcon: Icon(Icons.lock_reset_outlined,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _currentPasswordController.clear();
                _newPasswordController.clear();
                _confirmNewPasswordController.clear();
              },
            ),
            ElevatedButton(
              onPressed: () async {
                // Mock password change logic
                if (_currentPasswordController.text.isEmpty ||
                    _newPasswordController.text.isEmpty ||
                    _confirmNewPasswordController.text.isEmpty) {
                  CustomSnackBar.showError(context, 'All fields are required.');
                  return;
                }
                if (_newPasswordController.text !=
                    _confirmNewPasswordController.text) {
                  CustomSnackBar.showError(
                      context, 'New passwords do not match.');
                  return;
                }
                if (_newPasswordController.text.length < 6) {
                  CustomSnackBar.showError(context,
                      'New password must be at least 6 characters long.');
                  return;
                }

                // Simulate password change
                // In a real app, you'd call authService.changePassword(currentUserUid, current, new)
                await Future.delayed(const Duration(
                    milliseconds: 500)); // Simulate network delay

                CustomSnackBar.showSuccess(
                    context, 'Password changed successfully (simulated)!');
                Navigator.of(context).pop();
                _currentPasswordController.clear();
                _newPasswordController.clear();
                _confirmNewPasswordController.clear();
              },
              style: Theme.of(context).elevatedButtonTheme.style,
              child: const Text('Change Password'),
            ),
          ],
        );
      },
    );
  }

  // Function to show Edit Profile Dialog
  void _showEditProfileDialog(BuildContext context, DataManager dataManager) {
    // Ensure _currentUserUid is not null before proceeding
    if (_currentUserUid == null) {
      CustomSnackBar.showError(
          context, 'You must be logged in to edit your profile.');
      return;
    }

    final Map<String, dynamic>? currentUser =
        dataManager.getUserById(_currentUserUid!);
    if (currentUser != null) {
      _editNameController.text = currentUser['name'] ?? '';
      _editEmailController.text = currentUser['email'] ?? '';
      _editPhoneController.text = currentUser['phone'] ?? '';
      _editAgeController.text = currentUser['age']?.toString() ?? '';
      _editLocationController.text = currentUser['location'] ?? '';
    } else {
      // This case should ideally not happen if _currentUserUid is not null,
      // but it's a good fallback for data consistency issues.
      CustomSnackBar.showError(context,
          'Failed to load current user profile data. Please try again.');
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Profile Information'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _editNameController,
                  decoration: InputDecoration(
                    labelText: 'Full Name',
                    prefixIcon: Icon(Icons.person,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _editEmailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    prefixIcon: Icon(Icons.email,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _editPhoneController,
                  decoration: InputDecoration(
                    labelText: 'Phone Number',
                    prefixIcon: Icon(Icons.phone,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  keyboardType: TextInputType.phone,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                // Age and Location are optional for CHW/Midwife, but present for Mother.
                // Keeping them here for a generic profile edit.
                const SizedBox(height: 10),
                TextFormField(
                  controller: _editAgeController,
                  decoration: InputDecoration(
                    labelText: 'Age',
                    prefixIcon: Icon(Icons.cake,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  keyboardType: TextInputType.number,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _editLocationController,
                  decoration: InputDecoration(
                    labelText: 'Location',
                    prefixIcon: Icon(Icons.location_on,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              onPressed: () async {
                // Mock profile update logic
                final updatedData = {
                  'name': _editNameController.text,
                  'email': _editEmailController.text,
                  'phone': _editPhoneController.text,
                  'age': int.tryParse(_editAgeController.text),
                  'location': _editLocationController.text,
                };
                // Ensure _currentUserUid is not null before updating
                if (_currentUserUid != null) {
                  dataManager.updateUser(_currentUserUid!, updatedData);
                  CustomSnackBar.showSuccess(
                      context, 'Profile updated successfully (simulated)!');
                } else {
                  CustomSnackBar.showError(
                      context, 'Error: User not identified for update.');
                }
                Navigator.of(context).pop();
              },
              style: Theme.of(context).elevatedButtonTheme.style,
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // Only listen to ThemeNotifier here, as it causes UI rebuilds.
    final themeNotifier = Provider.of<ThemeNotifier>(context);
    // Access AuthService and DataManager with listen: false if not causing rebuilds.
    // These are safe to access here in build because didChangeDependencies ensures setup.
    // Use the _authServiceInstance initialized in didChangeDependencies
    final dataManager = Provider.of<DataManager>(context, listen: false);

    // Show loading indicator if auth state is not yet checked
    if (!_isAuthChecked) {
      return Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: Center(
          child:
              CircularProgressIndicator(color: Theme.of(context).primaryColor),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'General Settings',
              style: AppStyles.headline3
                  .copyWith(color: Theme.of(context).primaryColor),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: AppStyles.cardDecoration(context),
              child: Column(
                children: [
                  // Language Selection
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.language,
                                color:
                                    Theme.of(context).listTileTheme.iconColor),
                            const SizedBox(width: 16),
                            Text('App Language',
                                style: AppStyles.bodyText1.copyWith(
                                    color: Theme.of(context)
                                            .listTileTheme
                                            .textColor ??
                                        Theme.of(context)
                                            .textTheme
                                            .bodyLarge
                                            ?.color)),
                          ],
                        ),
                        DropdownButton<String>(
                          value: _selectedLanguage,
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedLanguage = newValue!;
                              CustomSnackBar.showInfo(context,
                                  'Language set to $_selectedLanguage.');
                            });
                          },
                          items: <String>['English', 'Luganda', 'Swahili']
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                          underline: Container(),
                          style: Theme.of(context).dropdownMenuTheme.textStyle,
                          icon: Icon(Icons.arrow_drop_down,
                              color: Theme.of(context).primaryColor),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  // Theme Selection
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.palette_outlined,
                                color:
                                    Theme.of(context).listTileTheme.iconColor),
                            const SizedBox(width: 16),
                            Text('App Theme',
                                style: AppStyles.bodyText1.copyWith(
                                    color: Theme.of(context)
                                            .listTileTheme
                                            .textColor ??
                                        Theme.of(context)
                                            .textTheme
                                            .bodyLarge
                                            ?.color)),
                          ],
                        ),
                        DropdownButton<ThemeMode>(
                          value: themeNotifier.themeMode,
                          onChanged: (ThemeMode? newMode) {
                            if (newMode != null) {
                              themeNotifier.setThemeMode(newMode);
                              CustomSnackBar.showInfo(context,
                                  'Theme set to ${newMode.toString().split('.').last}.');
                            }
                          },
                          items: const [
                            DropdownMenuItem(
                              value: ThemeMode.system,
                              child: Text('System Default'),
                            ),
                            DropdownMenuItem(
                              value: ThemeMode.light,
                              child: Text('Light'),
                            ),
                            DropdownMenuItem(
                              value: ThemeMode.dark,
                              child: Text('Dark'),
                            ),
                          ],
                          underline: Container(), // Remove default underline
                          style: Theme.of(context)
                              .dropdownMenuTheme
                              .textStyle, // Use theme text style
                          icon: Icon(Icons.arrow_drop_down,
                              color: Theme.of(context).primaryColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'Notification Preferences',
              style: AppStyles.headline3
                  .copyWith(color: Theme.of(context).primaryColor),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: AppStyles.cardDecoration(context),
              child: Column(
                children: [
                  SwitchListTile(
                    title: Text('In-app Messaging',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    secondary: Icon(Icons.message_outlined,
                        color: Theme.of(context).listTileTheme.iconColor),
                    value: _inAppMessagingEnabled,
                    onChanged: (bool value) {
                      setState(() {
                        _inAppMessagingEnabled = value;
                        CustomSnackBar.showInfo(context,
                            'In-app messaging ${value ? 'enabled' : 'disabled'}.');
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  SwitchListTile(
                    title: Text('Receive Health Visit Reminders',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    secondary: Icon(Icons.event_note,
                        color: Theme.of(context).listTileTheme.iconColor),
                    value: _receiveVisitReminders,
                    onChanged: (bool value) {
                      setState(() {
                        _receiveVisitReminders = value;
                        CustomSnackBar.showInfo(context,
                            'Visit reminders ${value ? 'enabled' : 'disabled'}.');
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  SwitchListTile(
                    title: Text('Get Weekly Health Tips',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    secondary: Icon(Icons.lightbulb_outline,
                        color: Theme.of(context).listTileTheme.iconColor),
                    value: _getWeeklyTips,
                    onChanged: (bool value) {
                      setState(() {
                        _getWeeklyTips = value;
                        CustomSnackBar.showInfo(context,
                            'Weekly tips ${value ? 'enabled' : 'disabled'}.');
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  SwitchListTile(
                    title: Text('Panic Alert Confirmations',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    secondary: Icon(Icons.warning_amber_rounded,
                        color: AppColors.dangerColor),
                    value: _panicAlertConfirmations,
                    onChanged: (bool value) {
                      setState(() {
                        _panicAlertConfirmations = value;
                        CustomSnackBar.showInfo(context,
                            'Panic alert confirmations ${value ? 'enabled' : 'disabled'}.');
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'Account & Data',
              style: AppStyles.headline3
                  .copyWith(color: Theme.of(context).primaryColor),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: AppStyles.cardDecoration(context),
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(Icons.lock_outline,
                        color: Theme.of(context).listTileTheme.iconColor),
                    title: Text('Change Password',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      _showChangePasswordDialog(context,
                          _authServiceInstance); // Use the non-nullable instance
                    },
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  ListTile(
                    leading: Icon(Icons.person_outline,
                        color: Theme.of(context).listTileTheme.iconColor),
                    title: Text('Edit Profile Information',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      _showEditProfileDialog(context, dataManager);
                    },
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  SwitchListTile(
                    title: Text('Offline Mode (Beta)',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    secondary:
                        Icon(Icons.cloud_off, color: AppColors.infoColor),
                    value: _offlineModeEnabled,
                    onChanged: (bool value) {
                      setState(() {
                        _offlineModeEnabled = value;
                        CustomSnackBar.showInfo(context,
                            'Offline mode ${value ? 'enabled' : 'disabled'}. Data sync required.');
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  ListTile(
                    leading: Icon(Icons.logout, color: AppColors.dangerColor),
                    title: Text('Logout',
                        style: AppStyles.bodyText1
                            .copyWith(color: AppColors.dangerColor)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () async {
                      await _authServiceInstance
                          .logout(); // Use the non-nullable instance
                      Navigator.of(context).pushReplacementNamed('/');
                      CustomSnackBar.showInfo(
                          context, 'You have been logged out.');
                    },
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  ListTile(
                    leading: Icon(Icons.delete_outline,
                        color: AppColors.dangerColor),
                    title: Text('Delete Account',
                        style: AppStyles.bodyText1
                            .copyWith(color: AppColors.dangerColor)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      _showDeleteAccountConfirmationDialog(context,
                          _authServiceInstance); // Use the non-nullable instance
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'About MamaSave',
              style: AppStyles.headline3
                  .copyWith(color: Theme.of(context).primaryColor),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: AppStyles.cardDecoration(context),
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(Icons.info_outline,
                        color: Theme.of(context).listTileTheme.iconColor),
                    title: Text('About Us',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      CustomSnackBar.showInfo(
                          context, 'About Us information coming soon.');
                    },
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  ListTile(
                    leading: Icon(Icons.privacy_tip_outlined,
                        color: Theme.of(context).listTileTheme.iconColor),
                    title: Text('Privacy Policy',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      CustomSnackBar.showInfo(
                          context, 'Privacy Policy details coming soon.');
                    },
                  ),
                  Divider(
                      indent: 16,
                      endIndent: 16,
                      color: Theme.of(context).dividerColor),
                  ListTile(
                    leading: Icon(Icons.gavel_outlined,
                        color: Theme.of(context).listTileTheme.iconColor),
                    title: Text('Terms of Service',
                        style: AppStyles.bodyText1.copyWith(
                            color: Theme.of(context).listTileTheme.textColor ??
                                Theme.of(context).textTheme.bodyLarge?.color)),
                    trailing: Icon(Icons.arrow_forward_ios,
                        size: 18,
                        color: Theme.of(context)
                            .listTileTheme
                            .iconColor
                            ?.withOpacity(0.7)),
                    onTap: () {
                      CustomSnackBar.showInfo(
                          context, 'Terms of Service details coming soon.');
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Center(
              child: Text(
                'MamaSave App Version 1.0.0',
                style: AppStyles.bodyText2.copyWith(
                    color: Theme.of(context).textTheme.bodyMedium?.color),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Confirmation dialog for deleting account
  void _showDeleteAccountConfirmationDialog(
      BuildContext context, AuthService authService) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Account Deletion'),
          content: const Text(
            'Are you sure you want to permanently delete your account? This action cannot be undone.',
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.dangerColor),
              child: Text('Delete Account', style: AppStyles.buttonTextStyle),
              onPressed: () async {
                await authService.logout();
                CustomSnackBar.showSuccess(
                    context, 'Your account has been deleted (simulated).');
                Navigator.of(context).pushReplacementNamed('/');
              },
            ),
          ],
        );
      },
    );
  }
}
