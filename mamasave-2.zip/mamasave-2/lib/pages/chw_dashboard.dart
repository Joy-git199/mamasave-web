// lib/pages/chw_dashboard.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/auth_service.dart';
import 'package:mamasave/services/data_manager.dart';
import 'package:mamasave/models/health_visit.dart';
import 'package:mamasave/models/vitals_entry.dart';
import 'package:uuid/uuid.dart';
import 'package:mamasave/widgets/custom_snackbar.dart';

// The CHWDashboard provides a dedicated interface for Community Health Workers.
// They can log new visits, record vitals, note danger signs, and view visit history.
class CHWDashboard extends StatefulWidget {
  const CHWDashboard({super.key});

  @override
  State<CHWDashboard> createState() => _CHWDashboardState();
}

class _CHWDashboardState extends State<CHWDashboard> {
  // Mock CHW ID. In a real app, this would come from AuthService.
  final String _currentChwId = 'chw_mock';

  // Controllers for the new visit form
  final _formKey = GlobalKey<FormState>();
  String? _selectedMotherId;
  final TextEditingController _spo2Controller = TextEditingController();
  final TextEditingController _tempController = TextEditingController();
  final TextEditingController _hrController = TextEditingController();
  final TextEditingController _bpController = TextEditingController();
  // Removed weight and height controllers
  // final TextEditingController _weightController = TextEditingController();
  // final TextEditingController _heightController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final List<String> _selectedDangerSigns = [];

  bool _isAddingVisit = false;

  @override
  void dispose() {
    _spo2Controller.dispose();
    _tempController.dispose();
    _hrController.dispose();
    _bpController.dispose();
    // Removed weight and height controllers dispose
    // _weightController.dispose();
    // _heightController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  // Function to handle logging a new visit.
  Future<void> _logNewVisit() async {
    if (_formKey.currentState!.validate() && _selectedMotherId != null) {
      final dataManager = Provider.of<DataManager>(context, listen: false);
      const uuid = Uuid();

      final VitalsEntry newVitals = VitalsEntry(
        id: uuid.v4(),
        motherId: _selectedMotherId!,
        timestamp: DateTime.now(),
        spo2: double.tryParse(_spo2Controller.text),
        temperature: double.tryParse(_tempController.text),
        heartRate: int.tryParse(_hrController.text),
        bloodPressure:
            _bpController.text.isNotEmpty ? _bpController.text : null,
        // Removed weight and height from VitalsEntry creation
        // weight: double.tryParse(_weightController.text),
        // height: double.tryParse(_heightController.text),
      );

      await dataManager.addVitalsEntry(newVitals);

      final HealthVisit newVisit = HealthVisit(
        id: uuid.v4(),
        motherId: _selectedMotherId!,
        visitDate: DateTime.now(),
        visitorRole: 'CHW',
        visitorId: _currentChwId,
        notes: _notesController.text.isNotEmpty ? _notesController.text : null,
        vitals: newVitals,
        dangerSigns: List.from(_selectedDangerSigns),
      );

      await dataManager.addHealthVisit(newVisit);

      _formKey.currentState!.reset();
      _spo2Controller.clear();
      _tempController.clear();
      _hrController.clear();
      _bpController.clear();
      // Removed weight and height controllers clear
      // _weightController.clear();
      // _heightController.clear();
      _notesController.clear();
      setState(() {
        _selectedMotherId = null;
        _selectedDangerSigns.clear();
        _isAddingVisit = false;
      });

      CustomSnackBar.showSuccess(context,
          'Visit logged successfully for ${dataManager.getMotherNameById(newVisit.motherId)}!');
    } else {
      CustomSnackBar.showError(
          context, 'Please fill all required fields and select a mother.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final dataManager = Provider.of<DataManager>(context);
    final authService = Provider.of<AuthService>(context);

    final Map<String, dynamic>? currentUser =
        dataManager.getUserById(_currentChwId);
    final String chwName = currentUser?['name'] ?? 'CHW User';

    final List<HealthVisit> myChwVisits = dataManager
        .getAllHealthVisits()
        .where((visit) => visit.visitorId == _currentChwId)
        .toList();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('CHW Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              // Navigate to SettingsScreen for profile editing
              Navigator.of(context).pushNamed('/settings');
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authService.logout();
              Navigator.of(context).pushReplacementNamed('/');
              CustomSnackBar.showInfo(context, 'You have been logged out.');
            },
          ),
        ],
      ),
      drawer: _buildDrawer(context, authService, chwName),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Welcome, $chwName!',
              style: AppStyles.headline2.copyWith(
                  color: Theme.of(context).textTheme.displayMedium?.color),
            ),
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _isAddingVisit = !_isAddingVisit;
                  });
                },
                icon: Icon(
                    _isAddingVisit ? Icons.close : Icons.add_circle_outline,
                    size: 24,
                    color: Theme.of(context)
                        .elevatedButtonTheme
                        .style
                        ?.foregroundColor
                        ?.resolve(MaterialState.values.toSet())),
                label: Text(
                    _isAddingVisit ? 'Cancel Visit Log' : 'Log New Visit',
                    style: AppStyles.buttonTextStyle),
                style: AppStyles.primaryButtonStyle.copyWith(
                  backgroundColor: MaterialStateProperty.all(
                    _isAddingVisit
                        ? AppColors.dangerColor
                        : Theme.of(context).primaryColor,
                  ),
                  padding: MaterialStateProperty.all(
                      const EdgeInsets.symmetric(horizontal: 30, vertical: 15)),
                ),
              ),
            ),
            const SizedBox(height: 24),
            if (_isAddingVisit) ...[
              _buildSectionTitle('Log New Visit', Icons.add_box, context),
              const SizedBox(height: 16),
              _buildNewVisitForm(context, dataManager),
              const SizedBox(height: 24),
            ],
            _buildSectionTitle('My Visit History', Icons.history, context),
            const SizedBox(height: 16),
            _buildCHWVisitHistory(myChwVisits, dataManager, context),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // Builds the form for logging a new visit.
  Widget _buildNewVisitForm(BuildContext context, DataManager dataManager) {
    final List<String> allMotherIds = dataManager.getAllMotherIds();
    final List<String> dangerSignsOptions = [
      'Fever',
      'Severe Headache',
      'Blurred Vision',
      'Swelling in Legs/Face',
      'Vaginal Bleeding',
      'Severe Abdominal Pain',
      'Reduced Fetal Movement',
      'Difficulty Breathing',
      'Persistent Vomiting',
      'Convulsions'
    ];

    return Container(
      padding: const EdgeInsets.all(20.0),
      decoration: AppStyles.cardDecoration(context),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mother Information',
                style: AppStyles.headline3.copyWith(
                    color: Theme.of(context).textTheme.displaySmall?.color)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Select Mother',
                prefixIcon: Icon(Icons.person_search,
                    color: Theme.of(context).iconTheme.color),
              ),
              value: _selectedMotherId,
              hint: Text('Choose a mother',
                  style: Theme.of(context).inputDecorationTheme.hintStyle),
              items: allMotherIds.map((id) {
                return DropdownMenuItem(
                  value: id,
                  child: Text(dataManager.getMotherNameById(id),
                      style: Theme.of(context).textTheme.bodyLarge),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedMotherId = value;
                });
              },
              validator: (value) =>
                  value == null ? 'Please select a mother' : null,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 20),
            Text('Vitals Entry',
                style: AppStyles.headline3.copyWith(
                    color: Theme.of(context).textTheme.displaySmall?.color)),
            const SizedBox(height: 10),
            // Simplified vitals input layout as weight/height are removed
            Column(
              children: _buildVitalsInputFields(context),
            ),
            const SizedBox(height: 20),
            Text('Danger Signs',
                style: AppStyles.headline3.copyWith(
                    color: Theme.of(context).textTheme.displaySmall?.color)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8.0,
              runSpacing: 4.0,
              children: dangerSignsOptions.map((sign) {
                return FilterChip(
                  label: Text(sign),
                  selected: _selectedDangerSigns.contains(sign),
                  onSelected: (bool selected) {
                    setState(() {
                      if (selected) {
                        _selectedDangerSigns.add(sign);
                      } else {
                        _selectedDangerSigns.remove(sign);
                      }
                    });
                  },
                  selectedColor: AppColors.dangerColor.withOpacity(0.2),
                  checkmarkColor: AppColors.dangerColor,
                  labelStyle: AppStyles.bodyText2.copyWith(
                    color: _selectedDangerSigns.contains(sign)
                        ? AppColors.dangerColor
                        : Theme.of(context).textTheme.bodyMedium?.color,
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _notesController,
              decoration: InputDecoration(
                labelText: 'Additional Notes',
                prefixIcon:
                    Icon(Icons.notes, color: Theme.of(context).iconTheme.color),
                alignLabelWithHint: true,
              ),
              maxLines: 3,
              keyboardType: TextInputType.multiline,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: _logNewVisit,
                style: Theme.of(context).elevatedButtonTheme.style,
                child: const Text('Submit Visit'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper to build list of vital input TextFormFields
  List<Widget> _buildVitalsInputFields(BuildContext context) {
    return [
      TextFormField(
        controller: _spo2Controller,
        decoration: InputDecoration(
          labelText: 'SpO2 (%)',
          prefixIcon:
              Icon(Icons.monitor, color: Theme.of(context).iconTheme.color),
        ),
        keyboardType: TextInputType.number,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      const SizedBox(height: 10),
      TextFormField(
        controller: _tempController,
        decoration: InputDecoration(
          labelText: 'Temperature (°C)',
          prefixIcon:
              Icon(Icons.thermostat, color: Theme.of(context).iconTheme.color),
        ),
        keyboardType: TextInputType.number,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      const SizedBox(height: 10),
      TextFormField(
        controller: _hrController,
        decoration: InputDecoration(
          labelText: 'Heart Rate (bpm)',
          prefixIcon: Icon(Icons.favorite_border,
              color: Theme.of(context).iconTheme.color),
        ),
        keyboardType: TextInputType.number,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      const SizedBox(height: 10),
      TextFormField(
        controller: _bpController,
        decoration: InputDecoration(
          labelText: 'Blood Pressure (e.g., 120/80 mmHg)',
          prefixIcon:
              Icon(Icons.bloodtype, color: Theme.of(context).iconTheme.color),
        ),
        keyboardType: TextInputType.text,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      // Removed weight and height input fields
      // const SizedBox(height: 10),
      // TextFormField(
      //   controller: _weightController,
      //   decoration: InputDecoration(
      //     labelText: 'Weight (kg)',
      //     prefixIcon: Icon(Icons.scale, color: Theme.of(context).iconTheme.color),
      //   ),
      //   keyboardType: TextInputType.number,
      //   style: Theme.of(context).textTheme.bodyLarge,
      // ),
      // const SizedBox(height: 10),
      // TextFormField(
      //   controller: _heightController,
      //   decoration: InputDecoration(
      //     labelText: 'Height (cm)',
      //     prefixIcon: Icon(Icons.height, color: Theme.of(context).iconTheme.color),
      //   ),
      //   keyboardType: TextInputType.number,
      //   style: Theme.of(context).textTheme.bodyLarge,
      // ),
    ];
  }

  // Builds a section title with an icon.
  Widget _buildSectionTitle(String title, IconData icon, BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: Theme.of(context).primaryColor, size: 28),
        const SizedBox(width: 10),
        Text(
          title,
          style: AppStyles.headline3
              .copyWith(color: Theme.of(context).textTheme.displaySmall?.color),
        ),
      ],
    );
  }

  // Builds the CHW's visit history section.
  Widget _buildCHWVisitHistory(
      List<HealthVisit> visits, DataManager dataManager, BuildContext context) {
    if (visits.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16.0),
        decoration: AppStyles.cardDecoration(context),
        child: Center(
          child: Text(
            'No visit history logged yet by you.',
            style: AppStyles.bodyText2.copyWith(
                fontStyle: FontStyle.italic,
                color: Theme.of(context).textTheme.bodyMedium?.color),
          ),
        ),
      );
    }

    visits.sort((a, b) => b.visitDate.compareTo(a.visitDate));

    return Container(
      decoration: AppStyles.cardDecoration(context),
      child: ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: visits.length,
        itemBuilder: (context, index) {
          final visit = visits[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0)),
            color: Theme.of(context).cardTheme.color,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Visit to: ${dataManager.getMotherNameById(visit.motherId)}',
                    style: AppStyles.subTitle
                        .copyWith(color: Theme.of(context).primaryColor),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Date: ${visit.visitDate.toLocal().toString().split(' ')[0]}',
                    style: AppStyles.bodyText2.copyWith(
                        color: Theme.of(context).textTheme.bodyMedium?.color),
                  ),
                  if (visit.vitals != null)
                    Text(
                      'Vitals: SpO2 ${visit.vitals!.spo2?.toStringAsFixed(1) ?? 'N/A'}%, Temp ${visit.vitals!.temperature?.toStringAsFixed(1) ?? 'N/A'}°C, HR ${visit.vitals!.heartRate ?? 'N/A'} bpm, BP ${visit.vitals!.bloodPressure ?? 'N/A'}',
                      style: AppStyles.bodyText2.copyWith(
                          color: Theme.of(context).textTheme.bodyMedium?.color),
                    ),
                  if (visit.dangerSigns.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Danger Signs: ${visit.dangerSigns.join(', ')}',
                        style: AppStyles.bodyText2.copyWith(
                            color: AppColors.dangerColor,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  if (visit.notes != null && visit.notes!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Notes: ${visit.notes}',
                        style: AppStyles.bodyText2.copyWith(
                            color:
                                Theme.of(context).textTheme.bodyMedium?.color),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // Builds the navigation drawer for the CHW's dashboard.
  Widget _buildDrawer(
      BuildContext context, AuthService authService, String userName) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppColors.whiteTextColor.withOpacity(0.8),
                  child: Icon(
                    Icons.person,
                    size: 40,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  userName,
                  style: AppStyles.headline3
                      .copyWith(color: AppColors.whiteTextColor),
                ),
                Text(
                  'Community Health Worker Role',
                  style: AppStyles.bodyText2.copyWith(
                      color: AppColors.whiteTextColor.withOpacity(0.8)),
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.home,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Dashboard',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.people,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('All Mothers',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/all_mothers');
            },
          ),
          ListTile(
            leading: Icon(Icons.history,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('My Visit History',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed(
                '/visit_history',
                arguments: {'userId': _currentChwId, 'role': 'CHW'},
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.upload_file,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Documents & Records',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/documents_upload');
            },
          ),
          const Divider(),
          ListTile(
            leading: Icon(Icons.settings,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Settings',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/settings');
            },
          ),
          ListTile(
            leading: Icon(Icons.help_outline,
                color: Theme.of(context).listTileTheme.iconColor),
            title: Text('Help & Support',
                style: AppStyles.bodyText1.copyWith(
                    color: Theme.of(context).listTileTheme.textColor ??
                        Theme.of(context).textTheme.bodyLarge?.color)),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/help_support');
            },
          ),
          ListTile(
            leading: Icon(Icons.logout, color: AppColors.dangerColor),
            title: Text('Logout',
                style:
                    AppStyles.bodyText1.copyWith(color: AppColors.dangerColor)),
            onTap: () async {
              Navigator.pop(context);
              await authService.logout();
              Navigator.of(context).pushReplacementNamed('/');
              CustomSnackBar.showInfo(context, 'You have been logged out.');
            },
          ),
        ],
      ),
    );
  }
}
