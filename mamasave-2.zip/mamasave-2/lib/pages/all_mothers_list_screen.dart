// lib/pages/all_mothers_list_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/data_manager.dart';

// The AllMothersListScreen displays a list of all registered mothers.
// This screen is accessible by CHWs and Midwives to view mother profiles.
class AllMothersListScreen extends StatefulWidget {
  const AllMothersListScreen({super.key});

  @override
  State<AllMothersListScreen> createState() => _AllMothersListScreenState();
}

class _AllMothersListScreenState extends State<AllMothersListScreen> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final dataManager = Provider.of<DataManager>(context);
    final List<Map<String, dynamic>> allMothers = dataManager.getAllMothers();

    final List<Map<String, dynamic>> filteredMothers =
        allMothers.where((mother) {
      final name = mother['name']?.toLowerCase() ?? '';
      final id = mother['id']?.toLowerCase() ?? '';
      final query = _searchQuery.toLowerCase();
      return name.contains(query) || id.contains(query);
    }).toList();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('All Registered Mothers'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search by name or ID...',
                prefixIcon: Icon(Icons.search,
                    color: Theme.of(context).iconTheme.color),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Theme.of(context).inputDecorationTheme.fillColor,
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 10.0, horizontal: 16.0),
              ),
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ),
      ),
      body: filteredMothers.isEmpty
          ? Center(
              child: Text(
                _searchQuery.isEmpty
                    ? 'No mothers registered yet.'
                    : 'No mothers found matching your search.',
                style: AppStyles.bodyText1.copyWith(
                    fontStyle: FontStyle.italic,
                    color: Theme.of(context).textTheme.bodyLarge?.color),
                textAlign: TextAlign.center,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: filteredMothers.length,
              itemBuilder: (context, index) {
                final mother = filteredMothers[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8.0),
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0)),
                  color: Theme.of(context).cardTheme.color,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16.0),
                    leading: CircleAvatar(
                      backgroundColor:
                          Theme.of(context).primaryColor.withOpacity(0.2),
                      child: Text(
                        mother['name']![0].toUpperCase(),
                        style: AppStyles.headline3
                            .copyWith(color: Theme.of(context).primaryColor),
                      ),
                    ),
                    title: Text(
                      mother['name']!,
                      style: AppStyles.bodyText1.copyWith(
                          color: Theme.of(context)
                              .listTileTheme
                              .textColor), // Corrected
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('ID: ${mother['id']}',
                            style: AppStyles.bodyText2.copyWith(
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.color)),
                        Text('Status: ${mother['pregnancyStatus']}',
                            style: AppStyles.bodyText2.copyWith(
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.color)),
                      ],
                    ),
                    trailing: Icon(Icons.arrow_forward_ios,
                        color: Theme.of(context)
                            .iconTheme
                            .color
                            ?.withOpacity(0.7)),
                    onTap: () {
                      Navigator.of(context).pushNamed(
                        '/mother_profile',
                        arguments: {'motherId': mother['id']},
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
