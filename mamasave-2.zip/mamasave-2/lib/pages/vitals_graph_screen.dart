// lib/pages/vitals_graph_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart'; // Import fl_chart
import 'package:mamasave/utils/app_colors.dart'; // Ensure this is the updated AppColors
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/data_manager.dart';
import 'package:mamasave/models/vitals_entry.dart';

// The VitalsGraphScreen displays a mother's vital signs history and trends using graphs.
class VitalsGraphScreen extends StatefulWidget {
  final String motherId;

  const VitalsGraphScreen({super.key, required this.motherId});

  @override
  State<VitalsGraphScreen> createState() => _VitalsGraphScreenState();
}

class _VitalsGraphScreenState extends State<VitalsGraphScreen> {
  // Define min/max values for graph axes based on typical vital ranges
  double minSpo2 = 90.0;
  double maxSpo2 = 100.0;
  double minTemp = 35.0;
  double maxTemp = 40.0;
  double minHr = 40.0;
  double maxHr = 120.0;
  double minBpSystolic = 80.0;
  double maxBpSystolic = 160.0;
  double minBpDiastolic = 50.0;
  double maxBpDiastolic = 100.0;

  @override
  Widget build(BuildContext context) {
    final dataManager = Provider.of<DataManager>(context);
    List<VitalsEntry> vitals =
        dataManager.getVitalsEntriesForMother(widget.motherId);

    // Determine current theme brightness for color selection
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    // Use the specific text colors defined in AppColors based on theme
    final Color currentTextColor =
        isDarkMode ? AppColors.textColorDark : AppColors.textColor;
    // Use the specific card/surface colors defined in AppColors based on theme for tooltips
    final Color currentCardColor =
        isDarkMode ? AppColors.darkCardColor : AppColors.lightCardColor;

    // Sort vitals by timestamp, oldest first for trend display
    vitals.sort((a, b) => a.timestamp.compareTo(b.timestamp));

    if (vitals.isEmpty) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
          title: const Text('Vitals Trends'),
        ),
        body: Center(
          child: Text(
            'No vital entries recorded yet for this mother.',
            style: AppStyles.bodyText1
                .copyWith(fontStyle: FontStyle.italic, color: currentTextColor),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    // Prepare data for graphs
    List<FlSpot> spo2Spots = [];
    List<FlSpot> tempSpots = [];
    List<FlSpot> hrSpots = [];
    List<FlSpot> bpSystolicSpots = [];
    List<FlSpot> bpDiastolicSpots = [];

    // Map timestamps to x-axis values (0, 1, 2, ...)
    for (int i = 0; i < vitals.length; i++) {
      final entry = vitals[i];
      if (entry.spo2 != null) spo2Spots.add(FlSpot(i.toDouble(), entry.spo2!));
      if (entry.temperature != null)
        tempSpots.add(FlSpot(i.toDouble(), entry.temperature!));
      if (entry.heartRate != null)
        hrSpots.add(FlSpot(i.toDouble(), entry.heartRate!.toDouble()));

      if (entry.bloodPressure != null) {
        final bpParts = entry.bloodPressure!.split('/');
        if (bpParts.length == 2) {
          final systolic = double.tryParse(bpParts[0]);
          final diastolic = double.tryParse(bpParts[1]);
          if (systolic != null)
            bpSystolicSpots.add(FlSpot(i.toDouble(), systolic));
          if (diastolic != null)
            bpDiastolicSpots.add(FlSpot(i.toDouble(), diastolic));
        }
      }
    }

    // Determine min/max X values for the graph (based on number of entries)
    double minX = 0;
    double maxX = (vitals.length > 0 ? (vitals.length - 1).toDouble() : 0);
    if (vitals.length == 1) maxX = 1; // Ensure a range for single point

    // Helper to create common titles data for the charts
    FlTitlesData _commonTitlesData(
        BuildContext context, List<VitalsEntry> vitals) {
      return FlTitlesData(
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            interval:
                (vitals.length > 5) ? (vitals.length / 5).ceilToDouble() : 1,
            getTitlesWidget: (value, meta) {
              int index = value.toInt();
              if (index >= 0 && index < vitals.length) {
                final date = vitals[index].timestamp;
                return SideTitleWidget(
                  axisSide: meta.axisSide,
                  space: 8.0,
                  child: Text(
                    '${date.day}/${date.month}',
                    style: AppStyles.bodyText2
                        .copyWith(color: currentTextColor, fontSize: 10),
                  ),
                );
              }
              return const Text('');
            },
          ),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 40,
            getTitlesWidget: (value, meta) {
              return Text(
                value.toInt().toString(),
                style: AppStyles.bodyText2
                    .copyWith(color: currentTextColor, fontSize: 10),
              );
            },
          ),
        ),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles:
            const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      );
    }

    LineChartData createLineChartData({
      required List<FlSpot> spots,
      required Color lineColor,
      required double minY,
      required double maxY,
      required String title,
    }) {
      return LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: true,
          horizontalInterval: (maxY - minY) / 4, // 4 intervals
          verticalInterval:
              vitals.length > 5 ? (vitals.length / 5).ceilToDouble() : 1,
          getDrawingHorizontalLine: (value) => FlLine(
            color: Theme.of(context).dividerColor,
            strokeWidth: 0.5,
          ),
          getDrawingVerticalLine: (value) => FlLine(
            color: Theme.of(context).dividerColor,
            strokeWidth: 0.5,
          ),
        ),
        titlesData:
            _commonTitlesData(context, vitals), // Use common titles data
        borderData: FlBorderData(
          show: true,
          border: Border.all(color: Theme.of(context).dividerColor, width: 1),
        ),
        minX: minX,
        maxX: maxX,
        minY: minY,
        maxY: maxY,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: lineColor,
            barWidth: 3,
            isStrokeCapRound: true,
            dotData: FlDotData(
              show: true,
              getDotPainter: (spot, percent, barData, index) =>
                  FlDotCirclePainter(
                radius: 4,
                color: lineColor,
                strokeWidth: 1,
                strokeColor: Theme.of(context).scaffoldBackgroundColor,
              ),
            ),
            belowBarData: BarAreaData(show: false),
          ),
        ],
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            // Corrected: Use getTooltipColor instead of tooltipBgColor
            getTooltipColor: (touchedSpot) => currentCardColor.withOpacity(0.8),
            getTooltipItems: (touchedSpots) {
              return touchedSpots.map((LineBarSpot touchedSpot) {
                final int index = touchedSpot.spotIndex;
                if (index >= 0 && index < vitals.length) {
                  final VitalsEntry entry = vitals[index];
                  String date =
                      '${entry.timestamp.day}/${entry.timestamp.month}/${entry.timestamp.year}';
                  String time =
                      '${entry.timestamp.hour}:${entry.timestamp.minute.toString().padLeft(2, '0')}';
                  String value = '';

                  // Determine which vital sign is being touched
                  if (title == 'SpO2') {
                    value = 'SpO2: ${entry.spo2?.toStringAsFixed(1) ?? 'N/A'}%';
                  } else if (title == 'Temperature') {
                    value =
                        'Temp: ${entry.temperature?.toStringAsFixed(1) ?? 'N/A'}°C';
                  } else if (title == 'Heart Rate') {
                    value = 'HR: ${entry.heartRate ?? 'N/A'} bpm';
                  } else if (title == 'Blood Pressure') {
                    value = 'BP: ${entry.bloodPressure ?? 'N/A'}';
                  }

                  return LineTooltipItem(
                    '$title\n$date $time\n$value',
                    AppStyles.bodyText2.copyWith(color: currentTextColor),
                  );
                }
                return null;
              }).toList();
            },
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Vitals Trends'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Vitals Trends for ${dataManager.getMotherNameById(widget.motherId)}',
              style: AppStyles.headline2.copyWith(color: currentTextColor),
            ),
            const SizedBox(height: 24),

            // SpO2 Graph
            _buildChartCard(
              context,
              'Oxygen Saturation (SpO2)',
              LineChart(createLineChartData(
                spots: spo2Spots,
                lineColor: AppColors.primaryColor,
                minY: minSpo2,
                maxY: maxSpo2,
                title: 'SpO2',
              )),
            ),
            const SizedBox(height: 24),

            // Temperature Graph
            _buildChartCard(
              context,
              'Temperature',
              LineChart(createLineChartData(
                spots: tempSpots,
                lineColor: AppColors.dangerColor,
                minY: minTemp,
                maxY: maxTemp,
                title: 'Temperature',
              )),
            ),
            const SizedBox(height: 24),

            // Heart Rate Graph
            _buildChartCard(
              context,
              'Heart Rate',
              LineChart(createLineChartData(
                spots: hrSpots,
                lineColor: AppColors.successColor,
                minY: minHr,
                maxY: maxHr,
                title: 'Heart Rate',
              )),
            ),
            const SizedBox(height: 24),

            // Blood Pressure Graph (Systolic and Diastolic on same graph)
            _buildChartCard(
              context,
              'Blood Pressure (Systolic/Diastolic)',
              LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: true,
                    horizontalInterval: (maxBpSystolic - minBpDiastolic) / 4,
                    verticalInterval: vitals.length > 5
                        ? (vitals.length / 5).ceilToDouble()
                        : 1,
                    getDrawingHorizontalLine: (value) => FlLine(
                      color: Theme.of(context).dividerColor,
                      strokeWidth: 0.5,
                    ),
                    getDrawingVerticalLine: (value) => FlLine(
                      color: Theme.of(context).dividerColor,
                      strokeWidth: 0.5,
                    ),
                  ),
                  titlesData: _commonTitlesData(
                      context, vitals), // Use common titles data
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(
                        color: Theme.of(context).dividerColor, width: 1),
                  ),
                  minX: minX,
                  maxX: maxX,
                  minY: minBpDiastolic,
                  maxY: maxBpSystolic,
                  lineBarsData: [
                    LineChartBarData(
                      spots: bpSystolicSpots,
                      isCurved: true,
                      color: AppColors.infoColor, // Systolic color (blue)
                      barWidth: 3,
                      isStrokeCapRound: true,
                      dotData: FlDotData(
                        show: true,
                        getDotPainter: (spot, percent, barData, index) =>
                            FlDotCirclePainter(
                          radius: 4,
                          color: AppColors.infoColor,
                          strokeWidth: 1,
                          strokeColor:
                              Theme.of(context).scaffoldBackgroundColor,
                        ),
                      ),
                      belowBarData: BarAreaData(show: false),
                    ),
                    LineChartBarData(
                      spots: bpDiastolicSpots,
                      isCurved: true,
                      color: AppColors
                          .accentColor, // Diastolic color (light green) - using accentColor from your AppColors
                      barWidth: 3,
                      isStrokeCapRound: true,
                      dotData: FlDotData(
                        show: true,
                        getDotPainter: (spot, percent, barData, index) =>
                            FlDotCirclePainter(
                          radius: 4,
                          color: AppColors.accentColor, // Diastolic color
                          strokeWidth: 1,
                          strokeColor:
                              Theme.of(context).scaffoldBackgroundColor,
                        ),
                      ),
                      belowBarData: BarAreaData(show: false),
                    ),
                  ],
                  lineTouchData: LineTouchData(
                    touchTooltipData: LineTouchTooltipData(
                      // Corrected: Use getTooltipColor instead of tooltipBgColor
                      getTooltipColor: (touchedSpot) =>
                          currentCardColor.withOpacity(0.8),
                      getTooltipItems: (touchedSpots) {
                        return touchedSpots.map((LineBarSpot touchedSpot) {
                          final int index = touchedSpot.spotIndex;
                          if (index >= 0 && index < vitals.length) {
                            final VitalsEntry entry = vitals[index];
                            String date =
                                '${entry.timestamp.day}/${entry.timestamp.month}/${entry.timestamp.year}';
                            String time =
                                '${entry.timestamp.hour}:${entry.timestamp.minute.toString().padLeft(2, '0')}';
                            String value =
                                'BP: ${entry.bloodPressure ?? 'N/A'}';

                            return LineTooltipItem(
                              'Blood Pressure\n$date $time\n$value',
                              AppStyles.bodyText2
                                  .copyWith(color: currentTextColor),
                            );
                          }
                          return null;
                        }).toList();
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper widget to build a consistent card wrapper for charts
  Widget _buildChartCard(BuildContext context, String title, Widget chart) {
    // Determine current theme brightness for color selection
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final Color currentTextColor =
        isDarkMode ? AppColors.textColorDark : AppColors.textColor;

    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: AppStyles.cardDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppStyles.headline3.copyWith(color: currentTextColor),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 200, // Fixed height for the chart area
            child: chart,
          ),
        ],
      ),
    );
  }
}
