// lib/pages/mother_profile_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mamasave/utils/app_colors.dart';
import 'package:mamasave/utils/app_styles.dart';
import 'package:mamasave/services/data_manager.dart';
import 'package:mamasave/models/contact.dart';
import 'package:mamasave/models/personal_note.dart';
import 'package:mamasave/widgets/custom_snackbar.dart';
import 'package:uuid/uuid.dart';

// The MotherProfileScreen displays a mother's detailed profile,
// including personal info, emergency contacts, and personal notes.
class MotherProfileScreen extends StatefulWidget {
  final String? motherId; // Optional: if viewing another mother's profile

  const MotherProfileScreen({super.key, this.motherId});

  @override
  State<MotherProfileScreen> createState() => _MotherProfileScreenState();
}

class _MotherProfileScreenState extends State<MotherProfileScreen> {
  // Mock current user ID. In a real app, this would come from AuthService.
  final String _currentUserId = 'mother_001';

  final TextEditingController _contactNameController = TextEditingController();
  final TextEditingController _contactPhoneController = TextEditingController();
  final TextEditingController _contactRelationshipController =
      TextEditingController();
  final TextEditingController _noteTitleController = TextEditingController();
  final TextEditingController _noteContentController = TextEditingController();

  @override
  void dispose() {
    _contactNameController.dispose();
    _contactPhoneController.dispose();
    _contactRelationshipController.dispose();
    _noteTitleController.dispose();
    _noteContentController.dispose();
    super.dispose();
  }

  // Adds a new emergency contact.
  void _addEmergencyContact(DataManager dataManager) {
    if (_contactNameController.text.isEmpty ||
        _contactPhoneController.text.isEmpty ||
        _contactRelationshipController.text.isEmpty) {
      CustomSnackBar.showError(
          context, 'Name, Phone Number, and Relationship cannot be empty.');
      return;
    }
    final String motherId = widget.motherId ?? _currentUserId;
    dataManager.addEmergencyContact(
      motherId,
      Contact(
        id: const Uuid().v4(),
        name: _contactNameController.text,
        phoneNumber: _contactPhoneController.text,
        relationship: _contactRelationshipController.text,
        isEmergencyContact: true,
      ),
    );
    _contactNameController.clear();
    _contactPhoneController.clear();
    _contactRelationshipController.clear();
    CustomSnackBar.showSuccess(context, 'Emergency contact added!');
    Navigator.of(context).pop(); // Close dialog
  }

  // Adds a new personal note.
  void _addPersonalNote(DataManager dataManager) {
    if (_noteTitleController.text.isEmpty ||
        _noteContentController.text.isEmpty) {
      CustomSnackBar.showError(
          context, 'Note title and content cannot be empty.');
      return;
    }
    final String motherId = widget.motherId ?? _currentUserId;
    dataManager.addPersonalNote(
      motherId,
      PersonalNote(
        id: const Uuid().v4(),
        userId: motherId,
        title: _noteTitleController.text,
        content: _noteContentController.text,
        createdAt: DateTime.now(),
      ),
    );
    _noteTitleController.clear();
    _noteContentController.clear();
    CustomSnackBar.showSuccess(context, 'Personal note added!');
    Navigator.of(context).pop(); // Close dialog
  }

  @override
  Widget build(BuildContext context) {
    final dataManager = Provider.of<DataManager>(context);
    final String displayMotherId = widget.motherId ?? _currentUserId;
    final Map<String, dynamic>? motherData =
        dataManager.getUserById(displayMotherId);

    if (motherData == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile Not Found')),
        body: Center(
          child: Text(
            'Mother profile with ID $displayMotherId not found.',
            style: AppStyles.bodyText1
                .copyWith(color: Theme.of(context).textTheme.bodyLarge?.color),
          ),
        ),
      );
    }

    final List<Contact> emergencyContacts =
        dataManager.getEmergencyContactsForMother(displayMotherId);
    final List<PersonalNote> personalNotes =
        dataManager.getPersonalNotesForMother(displayMotherId);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('${motherData['name']}\'s Profile'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileHeader(motherData, context),
            const SizedBox(height: 32),
            _buildSectionTitle(
                'Personal Information', Icons.person_outline, context),
            const SizedBox(height: 16),
            _buildInfoCard(motherData, context),
            const SizedBox(height: 32),
            _buildSectionTitle(
                'Emergency Contacts', Icons.contacts_outlined, context),
            const SizedBox(height: 16),
            _buildEmergencyContactsSection(
                emergencyContacts, dataManager, displayMotherId, context),
            const SizedBox(height: 32),
            _buildSectionTitle(
                'Personal Notes', Icons.note_alt_outlined, context),
            const SizedBox(height: 16),
            _buildPersonalNotesSection(
                personalNotes, dataManager, displayMotherId, context),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  // Builds the profile header with avatar and basic info.
  Widget _buildProfileHeader(
      Map<String, dynamic> motherData, BuildContext context) {
    return Center(
      child: Column(
        children: [
          CircleAvatar(
            radius: 60,
            backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
            child: Text(
              motherData['name']![0].toUpperCase(),
              style: AppStyles.headline1
                  .copyWith(color: Theme.of(context).primaryColor),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            motherData['name'] ?? 'N/A',
            style: AppStyles.headline2.copyWith(
                color: Theme.of(context).textTheme.displayMedium?.color),
          ),
          const SizedBox(height: 8),
          Text(
            'ID: ${motherData['id'] ?? 'N/A'}',
            style: AppStyles.bodyText2
                .copyWith(color: Theme.of(context).textTheme.bodyMedium?.color),
          ),
          const SizedBox(height: 8),
          Text(
            'Status: ${motherData['pregnancyStatus'] ?? 'N/A'}',
            style: AppStyles.bodyText2
                .copyWith(color: Theme.of(context).textTheme.bodyMedium?.color),
          ),
        ],
      ),
    );
  }

  // Builds a section title with an icon.
  Widget _buildSectionTitle(String title, IconData icon, BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: Theme.of(context).primaryColor, size: 28),
        const SizedBox(width: 10),
        Text(
          title,
          style: AppStyles.headline3
              .copyWith(color: Theme.of(context).textTheme.displaySmall?.color),
        ),
      ],
    );
  }

  // Builds the personal information card.
  Widget _buildInfoCard(Map<String, dynamic> motherData, BuildContext context) {
    return Container(
      decoration: AppStyles.cardDecoration(context),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoRow(
              'Email', motherData['email'], Icons.email_outlined, context),
          Divider(color: Theme.of(context).dividerColor),
          _buildInfoRow(
              'Phone', motherData['phone'], Icons.phone_outlined, context),
          Divider(color: Theme.of(context).dividerColor),
          _buildInfoRow('Age', motherData['age']?.toString(),
              Icons.cake_outlined, context),
          Divider(color: Theme.of(context).dividerColor),
          _buildInfoRow('Location', motherData['location'],
              Icons.location_on_outlined, context),
          Divider(color: Theme.of(context).dividerColor),
          _buildInfoRow(
              'CHW', motherData['assignedCHW'], Icons.person_outline, context),
          Divider(color: Theme.of(context).dividerColor),
          _buildInfoRow('Midwife', motherData['assignedMidwife'],
              Icons.medical_services_outlined, context),
        ],
      ),
    );
  }

  // Helper for building a single info row.
  Widget _buildInfoRow(
      String label, String? value, IconData icon, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Theme.of(context).iconTheme.color, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: AppStyles.bodyText2.copyWith(
                        color: Theme.of(context).textTheme.bodyMedium?.color)),
                Text(value ?? 'N/A',
                    style: AppStyles.bodyText1.copyWith(
                        color: Theme.of(context).textTheme.bodyLarge?.color)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Builds the emergency contacts section.
  Widget _buildEmergencyContactsSection(List<Contact> contacts,
      DataManager dataManager, String motherId, BuildContext context) {
    return Container(
      decoration: AppStyles.cardDecoration(context),
      child: Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: contacts.length,
            itemBuilder: (context, index) {
              final contact = contacts[index];
              return ListTile(
                leading: Icon(Icons.person_outline,
                    color: Theme.of(context).listTileTheme.iconColor),
                title: Text(
                  contact.name,
                  style: AppStyles.bodyText1.copyWith(
                      color: Theme.of(context).listTileTheme.textColor ??
                          Theme.of(context).textTheme.bodyLarge?.color),
                ),
                subtitle: Text(
                  '${contact.phoneNumber} - ${contact.relationship}',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                trailing: Row(
                  // Added Row for multiple trailing icons
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.phone,
                          color: Theme.of(context).iconTheme.color),
                      onPressed: () {
                        CustomSnackBar.showInfo(context,
                            'Calling ${contact.name} at ${contact.phoneNumber} (simulated)');
                        // TODO: Implement actual phone call
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline,
                          color: AppColors.dangerColor),
                      onPressed: () {
                        dataManager.removeEmergencyContact(
                            motherId, contact.id);
                        CustomSnackBar.showInfo(context, 'Contact removed.');
                      },
                    ),
                  ],
                ),
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: () => _showAddContactDialog(context, dataManager),
              icon: Icon(Icons.add_circle_outline,
                  color: Theme.of(context)
                      .elevatedButtonTheme
                      .style
                      ?.foregroundColor
                      ?.resolve(MaterialState.values.toSet())),
              label: const Text('Add Emergency Contact'),
              style: Theme.of(context).elevatedButtonTheme.style,
            ),
          ),
        ],
      ),
    );
  }

  // Dialog to add a new emergency contact.
  void _showAddContactDialog(BuildContext context, DataManager dataManager) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Emergency Contact'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _contactNameController,
                  decoration: InputDecoration(
                    labelText: 'Name',
                    prefixIcon: Icon(Icons.person,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _contactPhoneController,
                  decoration: InputDecoration(
                    labelText: 'Phone Number',
                    prefixIcon: Icon(Icons.phone,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  keyboardType: TextInputType.phone,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _contactRelationshipController,
                  decoration: InputDecoration(
                    labelText: 'Relationship (e.g., Husband, Sister)',
                    prefixIcon: Icon(Icons.people,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  maxLines: 1,
                  keyboardType: TextInputType.text,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _contactNameController.clear();
                _contactPhoneController.clear();
                _contactRelationshipController.clear();
              },
            ),
            ElevatedButton(
              onPressed: () => _addEmergencyContact(dataManager),
              style: Theme.of(context).elevatedButtonTheme.style,
              child: const Text('Add Contact'),
            ),
          ],
        );
      },
    );
  }

  // Builds the personal notes section.
  Widget _buildPersonalNotesSection(List<PersonalNote> notes,
      DataManager dataManager, String motherId, BuildContext context) {
    return Container(
      decoration: AppStyles.cardDecoration(context),
      child: Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: notes.length,
            itemBuilder: (context, index) {
              final note = notes[index];
              return ListTile(
                leading: Icon(Icons.note_outlined,
                    color: Theme.of(context).listTileTheme.iconColor),
                title: Text(
                  note.title, // Clearly show note title
                  style: AppStyles.bodyText1.copyWith(
                      color: Theme.of(context).listTileTheme.textColor ??
                          Theme.of(context).textTheme.bodyLarge?.color),
                ),
                subtitle: Text(
                  '${note.content.length > 50 ? note.content.substring(0, 47) + '...' : note.content} - ${note.createdAt.toLocal().toString().split(' ')[0]}', // Content snippet + date
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                trailing: Row(
                  // Added Row for multiple trailing icons
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit_outlined,
                          color: Theme.of(context).iconTheme.color),
                      onPressed: () {
                        CustomSnackBar.showInfo(context,
                            'Editing note: "${note.title}" (simulated)');
                        // TODO: Implement actual note editing logic
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline,
                          color: AppColors.dangerColor),
                      onPressed: () {
                        dataManager.removePersonalNote(motherId, note.id);
                        CustomSnackBar.showInfo(context, 'Note removed.');
                      },
                    ),
                  ],
                ),
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: () => _showAddNoteDialog(context, dataManager),
              icon: Icon(Icons.add_circle_outline,
                  color: Theme.of(context)
                      .elevatedButtonTheme
                      .style
                      ?.foregroundColor
                      ?.resolve(MaterialState.values.toSet())),
              label: const Text('Add Personal Note'),
              style: Theme.of(context).elevatedButtonTheme.style,
            ),
          ),
        ],
      ),
    );
  }

  // Dialog to add a new personal note.
  void _showAddNoteDialog(BuildContext context, DataManager dataManager) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Personal Note'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _noteTitleController,
                  decoration: InputDecoration(
                    labelText: 'Note Title',
                    hintText: 'Enter a title for your note',
                    prefixIcon: Icon(Icons.title,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _noteContentController,
                  decoration: InputDecoration(
                    labelText: 'Note Content',
                    hintText: 'Type your note here...',
                    prefixIcon: Icon(Icons.edit_outlined,
                        color: Theme.of(context).iconTheme.color),
                  ),
                  maxLines: 4,
                  keyboardType: TextInputType.multiline,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _noteTitleController.clear();
                _noteContentController.clear();
              },
            ),
            ElevatedButton(
              onPressed: () => _addPersonalNote(dataManager),
              style: Theme.of(context).elevatedButtonTheme.style,
              child: const Text('Add Note'),
            ),
          ],
        );
      },
    );
  }
}
