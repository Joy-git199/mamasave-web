package com.example.mamasave

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
