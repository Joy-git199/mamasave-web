# app.py
from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
from joblib import load

# Load model and encoder
pipeline, encoder = load("risk_model.joblib")

# Initialize app
app = FastAPI()

# Define input schema
class PatientData(BaseModel):
    HeartRate: float
    BodyTemp: float
    BloodOxygen: float
    ContractionFreq: float
    ContractionIntensity: float

# Define prediction endpoint
@app.post("/predict")
def predict_risk(data: PatientData):
    features = np.array([[ 
        data.HeartRate, 
        data.BodyTemp, 
        data.BloodOxygen, 
        data.ContractionFreq, 
        data.ContractionIntensity 
    ]])
    
    probs = pipeline.predict_proba(features)[0]
    pred_class = encoder.inverse_transform([np.argmax(probs)])[0]
    
    return {
        "prediction": pred_class,
        "probabilities": {
            "Low": round(probs[0], 3),
            "Mid": round(probs[1], 3),
            "High": round(probs[2], 3)
        }
    }
# Run the app with: uvicorn app:app --reload
# Ensure you have the model saved as 'risk_model.joblib' in the same directory.